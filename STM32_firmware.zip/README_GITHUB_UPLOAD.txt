GITHUB ACTIONS STM32 BUILD PACKAGE

Upload these TWO items to the ROOT of your GitHub repository:
1. STM32_Firmware.zip
2. .github/workflows/auto_zip_compile.yml  (keep this exact path)

IMPORTANT:
- Do NOT upload this outer package ZIP to GitHub as the firmware ZIP.
- Extract this package on your phone first, then upload STM32_Firmware.zip to the repository root.
- Create the workflow file at .github/workflows/auto_zip_compile.yml with the included file contents.
- In GitHub, open Actions and select "Upload ZIP - Build STM32 Firmware".
- If it does not start automatically, open the workflow and press "Run workflow".
- When the run finishes, open the successful run and download the artifact named STM32-Zipper-Firmware-Build.

Target: STM32F103C8T6 Blue Pill, Arduino STM32 core.
A successful compile has not been claimed yet; GitHub Actions must run to verify it.
